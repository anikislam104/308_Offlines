package packs;

public class Packages {
    private Microcontroller microcontroller;

    public Microcontroller getMicrocontroller() {
        return microcontroller;
    }

    public void setMicrocontroller(Microcontroller microcontroller) {
        this.microcontroller = microcontroller;
    }
    void print(){

    }
}
