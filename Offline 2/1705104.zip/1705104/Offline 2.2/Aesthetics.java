package Offline2;

public interface Aesthetics {
    String getName();
    void setName(String name);
}
