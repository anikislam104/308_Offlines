package Offline2;

public interface Parser {
    public String getFont();
    public void setFont(String font);
}
