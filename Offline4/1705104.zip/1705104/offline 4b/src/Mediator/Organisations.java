package Mediator;

public class Organisations {

}
