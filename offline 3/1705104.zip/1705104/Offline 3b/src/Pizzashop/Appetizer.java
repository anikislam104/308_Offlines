package Pizzashop;

public class Appetizer extends Decorator{
    public Appetizer(Meal meal) {
        super(meal);
    }
}
