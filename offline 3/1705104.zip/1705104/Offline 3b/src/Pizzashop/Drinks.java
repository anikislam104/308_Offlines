package Pizzashop;

public class Drinks extends Decorator{
    public Drinks(Meal meal) {
        super(meal);
    }
}
