package Pizzashop;

public interface Meal {
    public void show();
}
