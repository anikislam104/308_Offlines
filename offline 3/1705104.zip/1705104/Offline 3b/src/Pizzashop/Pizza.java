package Pizzashop;

public interface Pizza extends Meal{
    public void show();
}
