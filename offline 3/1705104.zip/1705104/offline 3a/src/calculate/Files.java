package calculate;

import java.io.File;

public interface Files {
   public File getFile();
}
